#include "PointLight.h"

Color PointLight::getColor()
{
	return m_Color;
}

Vec3 PointLight::getPosition()
{
	return m_Position;
}