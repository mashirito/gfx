#include "Object.h"

Object::Object()
{
	next = NULL;
}